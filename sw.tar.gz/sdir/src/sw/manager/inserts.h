// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2019 Egor Pugin <egor.pugin@gmail.com>

#include <string>

extern const std::string packages_db_schema;
